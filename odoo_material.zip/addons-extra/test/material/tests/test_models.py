from odoo.tests.common import TransactionCase
from odoo.exceptions import ValidationError


class TestMaterial(TransactionCase):
    def setUp(self, *args, **kwargs):
        result = super(TestMaterial, self).setUp(*args, **kwargs)
        self.supplier_model = self.env['material.supplier']
        self.material_model = self.env['material']
        self.supplier = self.create_supplier('Supplier 1', 'Jl. Supplier 1')
        return result

    def create_supplier(self, name, address):
        return self.supplier_model.create({
            'name': name,
            'address': address,
        })

    def test_material_buy_price(self):
        """
        Test if a validation error is raised when buy price is less than 100
        """
        with self.assertRaises(ValidationError):
            self.material_model.create({
                'code': 'M001',
                'name': 'Material 1',
                'type': 'fabric',
                'buy_price': 50,
                'sup_id': self.supplier.id,
                'material_type': 'fabric'
            })

    def test_material_filter(self):
        """
        Test if material filter action returns correct materials
        """
        material_1 = self.material_model.create({
            'code': 'M001',
            'name': 'Material 1',
            'type': 'fabric',
            'buy_price': 100,
            'sup_id': self.supplier.id,
            'material_type': 'fabric'
        })

        action = material_1.action_material_filter()
        materials = self.material_model.search(action.get('domain', []))
        self.assertEqual(len(materials), 1)
        self.assertEqual(materials, material_1)

    def test_create_material(self):
        """Test if a new material can be created successfully
        """
        material_vals = {
            'code': 'M003',
            'name': 'Material 3',
            'type': 'fabric',
            'buy_price': 150,
            'sup_id': self.supplier.id,
            'material_type': 'fabric'
        }
        material = self.material_model.create(material_vals)

        # check if material is created successfully
        self.assertEqual(material.code, 'M003')
        self.assertEqual(material.name, 'Material 3')
        self.assertEqual(material.type, 'fabric')
        self.assertEqual(material.buy_price, 150)
        self.assertEqual(material.sup_id.id, self.supplier.id)
        self.assertEqual(material.material_type, 'fabric')

        # try to create material with duplicate code, should raise validation error
        with self.assertRaises(ValidationError):
            self.material_model.create({
                'code': 'M003',
                'name': 'Material 4',
                'type': 'fabric',
                'buy_price': 200,
                'sup_id': self.supplier.id,
                'material_type': 'fabric'
            })

