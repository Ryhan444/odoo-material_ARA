# -*- coding: utf-8 -*-

from odoo.exceptions import UserError, ValidationError
from odoo import models, fields, api, _


class Material(models.Model):
    _name = 'material'
    _description = 'Material'

    code = fields.Char(
        string='Code',
        required=True
    )
    name = fields.Char(
        string='Name Material',
        required=True
    )

    type = fields.Selection([
        ('fabric', 'Fabric'),
        ('jeans', 'Jeans'),
        ('cotton', 'Cotton')
    ], default='fabric')
    buy_price = fields.Integer(
        string='Buy Price',
        required=True,
        placeholder="Currency value based on your country"
    )
    sup_id = fields.Many2one(
        'material.supplier', 
        string='Supplier', 
        required=True
    )

    @api.constrains('buy_price')
    def _check_buy_price(self):
        for rec in self:
            if rec.buy_price < 100:
                raise ValidationError('Buy price cannot be less than 100')

    def action_material_filter(self):
        self.ensure_one()
        action = self.env.ref('material.material_action').read()[0]
        action['domain'] = [('type', '=', self.type)]
        return action
    
class Supplier(models.Model):
    _name = 'material.supplier'
    _description = 'Supplier'

    name = fields.Char(
        required=True, 
        string='Name Supplier',
        index=True
    )
    address = fields.Char(
        string='Address'
    )
