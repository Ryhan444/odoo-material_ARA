from odoo import http
from odoo.http import request

class MaterialController(http.Controller):

    @http.route('/material/filter_by_type', type='json', auth='user')
    def action_filter_by_type(self, type):
        if type:
            materials = request.env['material'].sudo().search([('type', '=', type)])
            data = {
                'materials': materials.read(['id', 'name', 'type', 'buy_price', 'sup_id'])
            }
            return data
        else:
            return {}
