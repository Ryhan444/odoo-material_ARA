# -*- coding: utf-8 -*-
{
    'name': "Materials",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose
    """,

    'author': "Achmad Rayhan Alief",
    'website': "",
    'category': 'Custome',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',

    ],
        'models': [
        'models/models.py',
        # 'models/supplier.py',
    ],
        'test': [
        'tests/test_models.py',
    ],
    # only loaded in demonstration mode
    'demo': [
        # 'demo/demo.xml',
    ],
}
